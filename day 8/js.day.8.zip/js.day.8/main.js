/*
Description: jSlider
Author: Lyndon Modomo
Date: DATE GOES HERE
*/

$(function(){

	$('#jslider1').jslide({
		direction: 'vertical',
		prev: '#slideshow1 .prev',
		next: '#slideshow1 .next'
	});

});