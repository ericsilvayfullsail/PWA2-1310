/*
Description: jSlider
Author: Lyndon Modomo
Date: DATE GOES HERE
*/

$(function(){



});